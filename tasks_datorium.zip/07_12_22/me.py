teksts = 'Python' #string
skaitlis = 6 #integer   
decimals = 3.14 #float

saraksts = ['Python', 'Java', 'C#']
saraksts_ar_skaitliem = [5, 2, 7, 4, 6]

vardnica = {
    'vārds': 'Anna', 
    'uzvārds': 'Bērziņa',
    'adrese': 'Liepāja, LV-1111, Sniega iela 1'
}

saraksts_ar_vardnicam = [
    {
        'vārds': 'Anna', 
        'uzvārds': 'Bērziņa', 
        'adrese': 'Liepāja, LV-1111, Sniega iela 1'
    }, 
    {
        'vārds': 'Anna', 
        'uzvārds': 'Bērziņa', 
        'adrese': 'Liepāja, LV-1111, Sniega iela 1'
    }, 
    {
        'vārds': 'Anna', 
        'uzvārds': 'Bērziņa', 
        'adrese': 'Liepāja, LV-1111, Sniega iela 1'
    }
]

valoda = 'q;io4uhq;worgbvertiwg'

if valoda == 'Python':
    print('Es mācos Python')
elif valoda == "Java":
    print('Es mācos Java')
else:
    print('Es neko nedaru')


    valoda = 'Java'

if valoda.lower() == 'python':
    print('Es mācos Python')
elif valoda == "Java":
    print('Es mācos Java')
else:
    print('Es neko nedaru')