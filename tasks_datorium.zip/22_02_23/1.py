def SumTwoNumbers(a, b):
    print(a+b)

SumTwoNumbers(10, 28)

def MultiplyByTwo(x):
    print(2*x)

MultiplyByTwo(10)