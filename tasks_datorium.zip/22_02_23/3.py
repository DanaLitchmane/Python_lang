def SumTwoNumbers(a, b):
    return a+b

def JoinStrings(text1, text2, delimiter):
    return f"{text1}{delimiter}{text2}"

result = JoinStrings('One', 'Two', '-')
print(result)