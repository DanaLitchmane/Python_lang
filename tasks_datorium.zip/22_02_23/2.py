def SumTwoNumbers(a, b):
    return a+b

print(SumTwoNumbers(10, 20))
# var izdarīt kā mainīgo
# result = (SumTwoNumbers(10, 20))