contacts = []

while(True):
    response = input("A - add contact, P - print, E - exit: ")

    if response == "A" :
        name = input("Enter name:")
        surname = input("Enter surname:")
        phone = input("Enter phone:")
        email = input("Enter email:")

        contact = {
            'name' : name,
            'surname' : surname,
            'phone' : phone,
            'email' : email 
        }

        contacts.append(contact)
    elif response == "P":
        for contact in contacts:
            print(f"{contact['name']}")

    elif response == "E":
        break

        #print(contact)