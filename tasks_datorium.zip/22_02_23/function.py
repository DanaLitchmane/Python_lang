def SumTwoNumbers():
    print(5+6)

SumTwoNumbers()