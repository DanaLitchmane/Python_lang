name = 'Anna'
age = 17

print(f"Čau, mani sauc {name} un man ir {age} gadi.")

