file = open("deofile2.txt", "a")
file.write("Now the file has more content!")
file.close




file = open("data.txt", "a")
for i in range(1,101):
    file.write(f"Name{i}\n")

file.close()