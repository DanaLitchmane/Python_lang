import csv

file = open("atlase1.csv", "r")
csvFile = csv.reader(file, delimiter:=";")

for rinda in csvFile:
    print(rinda)