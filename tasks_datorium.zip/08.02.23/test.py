result = list(range(1, 11))
print(result)

for i in range(10):
    print(i)