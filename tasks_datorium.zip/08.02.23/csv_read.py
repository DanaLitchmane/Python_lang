import csv

file = open("list.csv", "r")
csvFile = csv.DictReader(file)

main_list = []

for rinda in csvFile:
    main_list.append(rinda)

print(main_list)