age = 18
average_grade = 10

if average_grade < 6:
    print('Reject!')
elif average_grade < 9:
    print('Maksas vieta!')
else:
    print('Budzets!')