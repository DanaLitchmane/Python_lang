import json

file = open('students.json', 'r')
dictionary = json. load(file)
file.close()

for student in dictionary['Students']:
    print(f"{student['FirstName'], student['LastName']}")