contacts = [
    {
        'name': 'Anna',
        'surname': 'Smart',
        'phone': '+37145678912',
        'email': 'anna.smart@somemail.com'
    },
    {
        'name': 'Oskars',
        'surname': 'Vitte',
        'phone': '+6549871654',
        'email': 'oskars@somemail.com'
    }
]