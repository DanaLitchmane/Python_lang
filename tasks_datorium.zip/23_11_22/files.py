file = open('data.txt', 'w')
file.write('Te ir faila saturs.')
file.close()