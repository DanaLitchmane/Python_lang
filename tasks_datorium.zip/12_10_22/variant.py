{
        'name': 'Anna', 
        'age': 17,
        'phone': '+371 123456789',
        #UZDEVUMS
        #Annai ir 2020. gada Audi marak sarkanā auto ar 2.0 litru dzinēju
        #arī ir 2022.gada Tesla markas melna auto ar 50w dzinēju 
        'cars' : [
            {
                'brand': 'Audi',
                'year': 2020,
                'color': 'Red',
                'engine': 2.0
            },
            {
                'brand': 'Tesla',
                'year': 2022,
                'color': 'Black',
                'engine': 50
            }
        ]
    }