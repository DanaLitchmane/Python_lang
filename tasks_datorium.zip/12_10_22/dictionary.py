contacts =[ 
    {
        'name':'Anna',
        'age':17,
        'phone': '+371 26458468',
        'car_1' : '2020.gada Audi murak sarkanā krāsā ar 2.0 litru dzīnēju',
        'car_2': '2022.gada Tesla melnā krāsā ar 50w dzinēju'
    }, 
    {
        'name':'Oskars',
        'age':20,
        'phone': '+371 41564564658',
      'car_1' : '2020.gada Audi murak sarkanā krāsā ar 2.0 litru dzīnēju',
        'car_2': '2022.gada Tesla melnā krāsā ar 50w dzinēju'
    }, 
    {
        'name':'Jenifer',
        'age':18,
        'phone': '+371 41564564658',
      'car_1' : '2020.gada Audi murak sarkanā krāsā ar 2.0 litru dzīnēju',
        'car_2': '2022.gada Tesla melnā krāsā ar 50w dzinēju'
    }, 
    {
        'name':'Miks',
        'age':16,
        'phone': '+371 41564564658',
      'car_1' : '2020.gada Audi murak sarkanā krāsā ar 2.0 litru dzīnēju',
        'car_2': '2022.gada Tesla melnā krāsā ar 50w dzinēju'
        }
]

for contact in contacts:
    print(contact['name'])
    print(contact['age'])
    print(contact['phone'])
    print(contact['car_1'])
    print(contact['car_2'])
    
     #UZDEVUMS
        #Annai ir 2020.gada Audi murak sarkanā krāsā ar 2.0 litru dzīnēju