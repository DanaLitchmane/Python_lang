saraksts = [1, 2, 3]
print[1] = 10
print(